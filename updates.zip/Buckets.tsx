import { useState, useEffect } from 'react';
import axios from 'axios';
import { Plus, Search, MoreVertical, Trash2, GitBranch } from 'lucide-react';
import { format } from 'date-fns';

export default function Buckets() {
  const [buckets, setBuckets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchBuckets();
  }, []);

  const fetchBuckets = async () => {
    try {
      const baseUrl = import.meta.env.VITE_API_URL || '';
      const token = localStorage.getItem('token');
      const res = await axios.get(`${baseUrl}/api/buckets`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setBuckets(res.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const formatBytes = (bytes: number) => {
    if (!bytes) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const createBucket = async () => {
    const name = prompt('Nome do Bucket:');
    if (!name) return;
    try {
      const baseUrl = import.meta.env.VITE_API_URL || '';
      const token = localStorage.getItem('token');
      await axios.post(`${baseUrl}/api/buckets`, { name, isPublic: false }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchBuckets();
    } catch (e) {
      alert('Erro ao criar bucket');
    }
  };

  return (
    <div className="space-y-4">
      {/* Top Actions */}
      <div className="flex justify-between items-center mb-6">
        <div className="flex gap-2">
          <button className="px-4 py-2 bg-[#2d2d35] hover:bg-[#3a3a44] text-gray-300 rounded-md text-sm transition-colors flex items-center gap-2">
            Regras de Ciclo de Vida
          </button>
          <button className="px-4 py-2 bg-[#2d2d35] hover:bg-[#3a3a44] text-gray-300 rounded-md text-sm transition-colors flex items-center gap-2">
            <Trash2 size={16} /> Excluir
          </button>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
            <input 
              type="text" 
              placeholder="Pesquisar" 
              className="bg-[#2d2d35] border-none text-sm text-white rounded-md pl-10 pr-4 py-2 focus:ring-1 focus:ring-eveo-red outline-none"
            />
          </div>
          <button 
            onClick={createBucket}
            className="px-4 py-2 bg-eveo-red hover:bg-eveo-redHover text-white font-medium rounded-md text-sm transition-colors flex items-center gap-2"
          >
            <Plus size={16} /> Criar
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="bg-[#2a2f3a] rounded-xl overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-eveo-red text-white text-sm">
              <th className="p-4 w-12"><input type="checkbox" className="rounded bg-black border-none" /></th>
              <th className="p-4 font-medium">Nome</th>
              <th className="p-4 font-medium text-center">Versionamento</th>
              <th className="p-4 font-medium text-center">Acesso</th>
              <th className="p-4 font-medium">Cota do Bucket</th>
              <th className="p-4 font-medium">URL Pública</th>
              <th className="p-4 font-medium">Criado</th>
              <th className="p-4 font-medium text-right">Ações</th>
            </tr>
          </thead>
          <tbody className="text-sm">
            {buckets.map((b, index) => (
              <tr key={b.id} className={`border-t border-[#3a3a44] ${index % 2 === 0 ? 'bg-[#2a2f3a]' : 'bg-[#2f3542]'}`}>
                <td className="p-4"><input type="checkbox" className="rounded bg-black border-none" /></td>
                <td className="p-4 font-medium text-white">{b.name}</td>
                <td className="p-4 text-center">
                  <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-green-500/20 text-green-500">
                    <GitBranch size={16} />
                  </div>
                </td>
                <td className="p-4 text-center">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${b.isPublic ? 'bg-green-500/20 text-green-500' : 'bg-red-500/20 text-red-500'}`}>
                    {b.isPublic ? 'Público' : 'Privado'}
                  </span>
                </td>
                <td className="p-4">
                  <div className="text-white font-medium">
                    {formatBytes(b.usedBytes)} <span className="text-gray-400 font-normal">/ {b.quotaBytes ? formatBytes(Number(b.quotaBytes)) : 'Unlimited'}</span>
                  </div>
                  {b.quotaBytes && (
                    <div className="w-full max-w-[150px] bg-gray-700 h-1 mt-2">
                      <div className="bg-white h-1" style={{ width: `${Math.min((b.usedBytes / Number(b.quotaBytes)) * 100, 100)}%` }}></div>
                    </div>
                  )}
                </td>
                <td className="p-4 text-gray-400 truncate max-w-[150px]">
                  {b.isPublic ? `${import.meta.env.VITE_API_URL || window.location.origin}/api/objects/bucket/${b.id}` : '-'}
                </td>
                <td className="p-4 text-gray-300">
                  {format(new Date(b.createdAt), 'dd/MM/yyyy')}
                </td>
                <td className="p-4 text-right">
                  <div className="flex items-center justify-end gap-3">
                    <button className="px-4 py-1.5 border border-eveo-red text-eveo-red hover:bg-eveo-red hover:text-white rounded transition-colors text-xs font-medium">
                      Explorar
                    </button>
                    <button className="text-gray-400 hover:text-white">
                      <MoreVertical size={18} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {buckets.length === 0 && !loading && (
              <tr>
                <td colSpan={8} className="p-8 text-center text-gray-400">Nenhum bucket encontrado.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
