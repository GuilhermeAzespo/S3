import { useState, useEffect } from 'react';
import axios from 'axios';
import { HardDrive, Container } from 'lucide-react';

export default function Dashboard() {
  const [stats, setStats] = useState({ totalBuckets: 0, totalObjects: 0, usedBytes: 0, totalQuota: 5 * 1024 * 1024 * 1024 * 1024 }); // Mock 5TB total for UI

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const baseUrl = import.meta.env.VITE_API_URL || '';
        const token = localStorage.getItem('token');
        const res = await axios.get(`${baseUrl}/api/buckets`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        
        let objects = 0;
        let bytes = 0;
        
        res.data.forEach((b: any) => {
          objects += b.objectCount || 0;
          bytes += b.usedBytes || 0;
        });

        setStats(prev => ({
          ...prev,
          totalBuckets: res.data.length,
          totalObjects: objects,
          usedBytes: bytes
        }));
      } catch (e) {
        console.error(e);
      }
    };
    fetchStats();
  }, []);

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const usagePercent = Math.min((stats.usedBytes / stats.totalQuota) * 100, 100);

  return (
    <div className="space-y-6">
      {/* Storage Quota Card - Mimicking screenshot */}
      <div className="bg-eveo-dark border border-eveo-red rounded-xl p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-white font-semibold flex items-center gap-2">
            <HardDrive size={18} className="text-gray-400" /> COTA DE ARMAZENAMENTO
          </h3>
          <div className="text-right">
            <span className="text-white font-bold">{formatBytes(stats.usedBytes)} / {formatBytes(stats.totalQuota)}</span>
            <span className="block text-gray-400 text-sm">{usagePercent.toFixed(1)}% usado</span>
          </div>
        </div>

        {/* Progress bar */}
        <div className="w-full bg-gray-200 rounded-full h-2.5 mb-6 dark:bg-gray-700">
          <div className="bg-green-500 h-2.5 rounded-full" style={{ width: `${usagePercent}%` }}></div>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-4 gap-4 text-center">
          <div>
            <span className="block text-gray-400 text-sm">Disponível</span>
            <span className="block text-white font-medium">{formatBytes(stats.totalQuota - stats.usedBytes)}</span>
          </div>
          <div>
            <span className="block text-gray-400 text-sm">Objetos</span>
            <span className="block text-white font-medium">{stats.totalObjects}</span>
          </div>
          <div>
            <span className="block text-gray-400 text-sm">Buckets</span>
            <span className="block text-white font-medium">{stats.totalBuckets}</span>
          </div>
          <div>
            <span className="block text-gray-400 text-sm">Status</span>
            <span className="inline-block mt-1 px-2 py-0.5 bg-green-500/20 text-green-500 text-xs rounded-full border border-green-500/50">OK</span>
          </div>
        </div>
      </div>

      {/* Total Buckets Card */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-[#2a2f3a] rounded-xl p-6 flex items-center gap-4">
          <Container size={32} className="text-gray-300" />
          <div>
            <span className="block text-gray-300 text-sm">Total de buckets</span>
            <span className="block text-white text-2xl font-bold">{stats.totalBuckets}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
